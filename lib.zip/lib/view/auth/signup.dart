import 'package:flutter/material.dart';
import 'package:ledgu/controller/signup_controller.dart';
import 'package:ledgu/utilties/colors.dart';
import 'package:ledgu/utilties/ottp.dart';
import 'package:ledgu/view/auth/login.dart';
import 'package:ledgu/widgets/button.dart';
import 'package:ledgu/widgets/gapbox.dart';
import 'package:ledgu/widgets/text.dart';
import 'package:ledgu/widgets/text_button.dart';
import 'package:ledgu/widgets/textformfield.dart';

class Signup extends StatelessWidget {
  Signup({super.key});

  final SignupController controller = SignupController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: AppColors.black1,
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(15.0),
            child: Column(
              children: [
                GapBox(12),
                MyText(
                  text: 'Register Account',
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                  fontSize: 18,
                ),
                MyText(
                  text:
                      'You can add personal details to\n strong the pos store profile.',
                  color: AppColors.grey1,
                  fontSize: 12,
                  fontWeight: FontWeight.w400,
                ),
                GapBox(12),

                // ===========================
                // Input Fields with Controllers
                // ===========================
                MyTextFormField(
                  labelText: 'Full Name',
                  hintText: 'Enter  Here',
                  controller: controller.nameController,
                ),
                GapBox(10),
                MyTextFormField(
                  labelText: 'Contact No',
                  hintText: 'Enter  Here',
                  controller: controller.contactController,
                ),
                GapBox(10),
                MyTextFormField(
                  labelText: 'City',
                  hintText: 'Enter  Here',
                  controller: controller.cityController,
                ),
                GapBox(10),
                MyTextFormField(
                  labelText: 'Email',
                  hintText: 'Enter  Here',
                  controller: controller.emailController,
                ),

                GapBox(20),
                MyText(
                  text: 'Enter Your Secret PIN',
                  color: AppColors.grey1,
                  fontWeight: FontWeight.w600,
                ),
                GapBox(10),
                AppPinFields(
                  length: 4,
                  onCompleted: (value) => controller.pinController.text = value,
                ),
                GapBox(21),

                // ===========================
                // Signup Button
                // ===========================
                MyButton(
                  text: 'Signup',
                  backgroundColor: AppColors.blue2,
                  onPressed: () async {
                    final user = await controller.registerUser(context);
                    if (user != null) {
                      controller.clearFields();
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (_) => Login()),
                      );
                    }
                  },
                ),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    MyText(
                      text: "Have account?",
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w400,
                    ),
                    MyTextButton(
                      text: 'Login',
                      textColor: AppColors.buttonColor,
                      fontSize: 12,
                      fontWeight: FontWeight.w400,
                      onPressed: () {
                        Navigator.pop(context); // go back to login screen
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
