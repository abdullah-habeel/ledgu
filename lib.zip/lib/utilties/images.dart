class MyImages {
  static const String image = 'assets/image.png';
}
