import 'package:flutter/material.dart';
import 'package:ledgu/utilties/colors.dart';

class MyButton extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;
  final Color foregroundColor;
  final Color backgroundColor;
  final Color borderColor;
  final double borderWidth;
  final double height;
  final double borderRadius;
  final double? widthFactor; // nullable
  final double? fixedWidth;  // optional fixed width

  const MyButton({
    super.key,
    required this.text,
    required this.onPressed,
    this.foregroundColor = Colors.white,
    this.backgroundColor = AppColors.buttonColor,
    this.borderColor = Colors.transparent,
    this.borderWidth = 1,
    this.height = 50,
    this.borderRadius = 12,
    this.widthFactor = 0.8,  // default 80%
    this.fixedWidth,          // optional
  });

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    double finalWidth;
    if (fixedWidth != null) {
      finalWidth = fixedWidth!; // use fixed width if provided
    } else if (widthFactor != null) {
      finalWidth = screenWidth * widthFactor!; // use factor
    } else {
      finalWidth = double.infinity; // fallback
    }

    return SizedBox(
      width: finalWidth,
      height: height,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: backgroundColor,
          foregroundColor: foregroundColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(borderRadius),
            side: BorderSide(color: borderColor, width: borderWidth),
          ),
        ),
        child: Text(
          text,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
      ),
    );
  }
}
