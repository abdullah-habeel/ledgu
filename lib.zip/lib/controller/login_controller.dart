import 'package:firebase_auth/firebase_auth.dart';
import 'auth_controller.dart';

class LoginController {
  final AuthController _authController = AuthController();

  Future<User?> login(String email, String password) async {
    return await _authController.loginWithEmail(email, password);
  }

  Future<void> logout() async {
    await _authController.logout();
  }

  User? getCurrentUser() {
    return _authController.currentUser;
  }
}
