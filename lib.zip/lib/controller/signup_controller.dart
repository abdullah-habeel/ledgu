// ignore_for_file: use_build_context_synchronously

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:ledgu/services/auth_services.dart';

class SignupController {
  final AuthServices auth = AuthServices();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Text Controllers
  final TextEditingController nameController = TextEditingController();
  final TextEditingController contactController = TextEditingController();
  final TextEditingController cityController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController pinController = TextEditingController();

  // ============================
  // REGISTER / CREATE USER
  // ============================
  Future<User?> registerUser(BuildContext context) async {
    try {
      // 1. Create user with AuthServices
      User? user = await auth.registerUser(
        email: emailController.text.trim(),
        password: pinController.text.trim(),
      );

      if (user != null) {
        // 2. Generate auto-increment user ID
        int userId = await _getNextUserId();

        // 3. Save additional info in Firestore
        await _firestore.collection('users').doc(user.uid).set({
          'user_id': userId,
          'name': nameController.text.trim(),
          'contact': contactController.text.trim(),
          'city': cityController.text.trim(),
          'email': emailController.text.trim(),
          'created_at': FieldValue.serverTimestamp(),
        });

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Signup Successful')),
        );

        return user;
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Signup Failed')),
        );
        return null;
      }
    } catch (e) {
      debugPrint('SignupController Error: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Unknown Signup Error')),
      );
      return null;
    }
  }

  // ============================
  // GET NEXT AUTO-INCREMENT USER ID
  // ============================
  Future<int> _getNextUserId() async {
    try {
      QuerySnapshot snapshot = await _firestore
          .collection('users')
          .orderBy('user_id', descending: true)
          .limit(1)
          .get();

      if (snapshot.docs.isEmpty) {
        return 1; // First user
      } else {
        int lastId = snapshot.docs.first['user_id'] ?? 0;
        return lastId + 1;
      }
    } catch (e) {
      debugPrint('Error generating user ID: $e');
      return DateTime.now().millisecondsSinceEpoch; // fallback unique ID
    }
  }

  // ============================
  // CLEAR INPUT FIELDS
  // ============================
  void clearFields() {
    nameController.clear();
    contactController.clear();
    cityController.clear();
    emailController.clear();
    pinController.clear();
  }
}
