import 'package:flutter/material.dart';
import 'package:ledgu/utilties/colors.dart';
import 'package:ledgu/utilties/images.dart';
import 'package:ledgu/widgets/gapbox.dart';
import 'package:ledgu/widgets/list_tile.dart';
import 'package:ledgu/widgets/text.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: AppColors.black1,
        body: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GapBox(15),
              Center(
                child: CircleAvatar(
                  radius: 70,
                  backgroundImage: AssetImage(MyImages.image),
                ),
              ),
              GapBox(15),
              Center(
                child: MyText(
                  text: 'Full Name',
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: AppColors.grey1,
                ),
              ),
              GapBox(15),
              Center(
                child: MyText(
                  text: '+92 3225169965 | Address',
                  color: AppColors.grey1,
                  fontSize: 10,
                  fontWeight: FontWeight.w500,
                ),
              ),
              GapBox(15),
              MyListTile(
                leadingIcon: Icons.settings,
                title: 'Profile Setting',
                onTap: () {},
                onTrailingTap: () {},
              ),
              GapBox(10),
              MyText(
                text: 'Others',
                fontWeight: FontWeight.w600,
                fontSize: 10,
                color: AppColors.grey1,
              ),
              GapBox(10),
              MyListTile(
                leadingIcon: Icons.info_outline,
                title: 'About More',
                onTap: () {},
                onTrailingTap: () {},
              ),
              MyListTile(
                leadingIcon: Icons.support_agent,
                title: 'Help & Support',
                onTap: () {},
                onTrailingTap: () {},
              ),
              MyListTile(
                leadingIcon: Icons.share_outlined,
                title: 'Share App',
                onTap: () {},
                onTrailingTap: () {},
              ),
            ],
          ),
        ),
      ),
    );
  }
}
