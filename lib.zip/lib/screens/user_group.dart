import 'package:flutter/material.dart';
import 'package:ledgu/utilties/colors.dart';
import 'package:ledgu/widgets/button.dart';
import 'package:ledgu/widgets/gapbox.dart';
import 'package:ledgu/widgets/icon_button.dart';
import 'package:ledgu/widgets/text.dart';
import 'package:ledgu/widgets/textformfield.dart';

class UserGroupScreen extends StatefulWidget {
  const UserGroupScreen({super.key});

  @override
  State<UserGroupScreen> createState() => _UserGroupScreenState();
}

class _UserGroupScreenState extends State<UserGroupScreen>
    with SingleTickerProviderStateMixin {
  late TabController tabController;

  @override
  void initState() {
    super.initState();
    tabController = TabController(length: 2, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: AppColors.black1,
        appBar: AppBar(
          backgroundColor: AppColors.black2,
          leading: MyIconButton(
            icon: Icons.chevron_left,
            color: Colors.white,
            onPressed: () {},
          ),
          title: MyText(
            text: 'ADD Account',
            color: Colors.white,
            fontWeight: FontWeight.w500,
            fontSize: 16,
          ),
          centerTitle: true,
        ),

        body: Column(
          children: [
            const SizedBox(height: 20),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: TabBar(
                controller: tabController,
                labelColor: Colors.blue,
                unselectedLabelColor: Colors.white,

                indicator: const UnderlineTabIndicator(
                  borderSide: BorderSide(width: 3, color: Colors.blue),
                  insets: EdgeInsets.symmetric(horizontal: 100),
                ),

                tabs: const [
                  Tab(text: "User"),
                  Tab(text: "Group"),
                ],
              ),
            ),

            const SizedBox(height: 14),

            /// TAB VIEW
            Expanded(
              child: TabBarView(
                controller: tabController,
                children: [buildUserTab(), buildGroupTab()],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// USER TAB
  Widget buildUserTab() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: [
          MyTextFormField(hintText: 'Enter Here', labelText: 'Email'),
          GapBox(10),
          MyButton(text: 'Continue',backgroundColor: AppColors.blue2,fixedWidth: double.infinity, onPressed: () {}),
        ],
      ),
    );
  }

  /// GROUP TAB
  Widget buildGroupTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          MyTextFormField(labelText: 'Group Title', hintText: 'Enter Here'),
          GapBox(10),

          MyTextFormField(labelText: 'Info', hintText: 'Enter Here'),
          GapBox(10),

          MyTextFormField(labelText: 'Select User', hintText: 'Enter Here'),
          GapBox(20),

          MyButton(text: 'Update',widthFactor: null, fixedWidth: double.infinity, backgroundColor: AppColors.blue2, onPressed: () {}),

          SizedBox(height: 30),
        ],
      ),
    );
  }
}
