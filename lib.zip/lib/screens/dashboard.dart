import 'package:flutter/material.dart';
import 'package:ledgu/utilties/colors.dart';
import 'package:ledgu/widgets/amount_container.dart';
import 'package:ledgu/widgets/gapbox.dart';
import 'package:ledgu/widgets/info_container.dart';
import 'package:ledgu/widgets/text.dart';
import 'package:ledgu/widgets/transaction_tile.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  int currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: AppColors.black1,

        

        appBar: AppBar(
          backgroundColor: AppColors.black2,
          title: MyText(
            text: 'DashBoard',
            color: Colors.white,
            fontWeight: FontWeight.w500,
          ),
          centerTitle: true,
        ),

        body: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              MyText(
                text: 'My Wallet',
                color: AppColors.grey1,
                fontSize: 10,
                fontWeight: FontWeight.w700,
              ),
              GapBox(20),

              Row(
                children: [
                  Expanded(
                    child: AmountContainer(
                      topText: '15,000',
                      bottomText: 'Will Received',
                       containerColor: AppColors.blue1,
                      topTextColor: AppColors.green,
                      
                    ),
                  ),
                  SizedBox(width: 10),
                  Expanded(
                    child: AmountContainer(
                      topText: '20,000',
                      bottomText: 'Will Paid',
                      containerColor: AppColors.blue1,
                      topTextColor: AppColors.red,
                    ),
                  ),
                ],
              ),

              GapBox(10),

              Row(
  children: [
    Expanded(
      child: InfoContainer(
        iconData: Icons.group_rounded,
        number: 15,
        bottomText: 'Friend',
      ),
    ),
    SizedBox(width: 5),

    Expanded(
      child: InfoContainer(
        iconData: Icons.groups_rounded,
        number: 10,
        bottomText: 'Groups',
      ),
    ),
    SizedBox(width: 5),

    Expanded(
      child: InfoContainer(
        iconData: Icons.pending_actions_rounded,
        number: 8,
        bottomText: 'Pending',
      ),
    ),
    SizedBox(width: 5),

    Expanded(
      child: InfoContainer(
        iconData: Icons.payments_rounded,
        number: 20,
        bottomText: 'To Pay',
      ),
    ),
  ],
)
,

              GapBox(10),
              ListTile(
                leading: MyText(
                  text: 'Transaction',
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  fontSize: 17,
                ),
                trailing: MyText(
                  text: 'See All',
                  color: AppColors.blue2,
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Divider(color: AppColors.grey1, thickness: 0.5),

              Expanded(
                child: ListView(
                  children: [
                    TransactionTile(
                      title: 'Noman',
                      subtitle: 'Dinner with friends',
                      date: '15 Nov 2025',
                      amount: 15000,
                    ),
                    TransactionTile(
                      title: 'Ali',
                      subtitle: 'Office Dinner',
                      date: '15 Nov 2025',
                      amount: -4500,
                    ),
                    TransactionTile(
                      title: 'Noman',
                      subtitle: 'Mobile Pkg',
                      date: '15 Nov 2025',
                      amount: -1200,
                    ),
                    TransactionTile(
                      title: 'Umer',
                      subtitle: 'Patrol',
                      date: '15 Nov 2025',
                      amount: 3000,
                    ),
                    TransactionTile(
                      title: 'Ahmed',
                      subtitle: 'Send Easypaisa',
                      date: '15 Nov 2025',
                      amount: -2000,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
